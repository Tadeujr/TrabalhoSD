
public interface Conjunto {
	
	public String run(String Expessao);
}
