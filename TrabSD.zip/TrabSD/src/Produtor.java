import org.apache.activemq.*;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

public class Produtor {
	
	public String servico;
	
	
	 // URL do servidor JMSr.
    private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    
    //Nome da fila para onde vai a mensagem
    

    public static void main(String[] args) throws JMSException {
    	int cont = 10;
		
    	// conexão
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
        Connection connection = connectionFactory.createConnection();
        connection.start();
        // Mensagens JMS são enviadas usando uma sessão.
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        
        Destination destination;
        MessageProducer producer;
        TextMessage message;
        
    	while(cont != 0){
    		
    		if(cont %2 == 0) {
                //Destination é a fila para onde as mensagens serão enviadas. 
                 destination = session.createQueue("FILASERVICO1");
                 producer = session.createProducer(destination);
                 //retorno da resposta 
                 message = session.createTextMessage("Resposta da fila 1");
                 // envia a mensagem enviar resposta do serviço
                 producer.send(message);

    		}else {
                //Destination é a fila para onde as mensagens serão enviadas. 
                destination = session.createQueue("FILASERVICO2");
                producer = session.createProducer(destination);
                //retorno da resposta 
                message = session.createTextMessage("Resposta da fila 2");
                // envia a mensagem enviar resposta do serviço
                producer.send(message);
              
    		}
    		
            
    		cont--;
    	}
    	System.out.println("Filas Criadas");
    	connection.close();
       


        
        

        
    }
}
