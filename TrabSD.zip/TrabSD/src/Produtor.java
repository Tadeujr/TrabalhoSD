import org.apache.activemq.*;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

public class Produtor {
	
	public String servico;
	
	
	 // URL do servidor JMSr. DEFAULT_BROKER_URL irá dizer que o server está no localhost
    private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    
    //Nome da fila para onde vai a mensagem
    private static String subject = "FILA_DE_SERVICOS";

    public static void main(String[] args) throws JMSException {
    	// conexão
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
        Connection connection = connectionFactory.createConnection();
        connection.start();


        // Mensagens JMS são enviadas usando uma sessão. Nós criaremos aqui uma sessão não transacional, informando false para o primeiro parametro 
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

        //Destination é a fila para onde as mensagens serão enviadas. 
        Destination destination = session.createQueue(subject);
        MessageProducer producer = session.createProducer(destination);
        //System.out.println(producer.getDeliveryMode());
        //retorno da resposta 
        
        HelloWord hl = new HelloWord();
        TextMessage message = session.createTextMessage(hl.run(""));

        // envia a mensagem enviar resposta do serviço
        producer.send(message);
        
        System.out.println("Mensagem enviada");

        connection.close();
    }
}
