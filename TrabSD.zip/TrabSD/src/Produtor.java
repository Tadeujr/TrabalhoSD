import org.apache.activemq.*;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

public class Produtor {
	
	public String servico;
	
	
	 // URL do servidor JMSr.
    private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    
    //Nome da fila para onde vai a mensagem
    private static String subject = "CALCULADORA";

    public static void main(String[] args) throws JMSException {
    	// conexão
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
        Connection connection = connectionFactory.createConnection();
        connection.start();


        // Mensagens JMS são enviadas usando uma sessão.
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

        //Destination é a fila para onde as mensagens serão enviadas. 
        Destination destination = session.createQueue(subject);
        MessageProducer producer = session.createProducer(destination);
        //System.out.println(producer.getDeliveryMode());
       
        
        HelloWord hl = new HelloWord();
        Calculadora c = new Calculadora();
         
        //retorno da resposta 
        TextMessage message = session.createTextMessage(c.run("1+1"));

        // envia a mensagem enviar resposta do serviço
        producer.send(message);
        
        System.out.println("Mensagem enviada");

        connection.close();
    }
}
