
public class HelloWord implements Conjunto{

	@Override
	public String run(String Expessao) {
		Expessao = "Ola Mundo!"; 
		return Expessao;
	}

}
